import os
from gtts import gTTS
import subprocess
import re

match_url = "https://statsfut.com/pt-br/match/553234/operario-vs-america-mg/"

texto_roteiro = """
Analisamos o confronto entre Operario e America Mineiro pela Série B. O Operario joga em casa, com cinquenta por cento de chances de vitória, enquanto o America tem vinte e quatro por cento. O cenário sugere um jogo truncado, com tendência a poucos gols e forte influência do mando de campo.

[ABA: gols] [FOCO: Over 1.5] Iniciando as estatísticas de Over 1.5, a probabilidade de over 1.5 gols é de setenta e sete por cento, indicando alta tendência de haver pelo menos dois gols na partida. Historicamente, os jogos da Série B têm pouca média de gols, mas esse número sugere que as defesas não devem prevalecer totalmente, abrindo espaço para finalizações. [OFF] [FOCO: Over 2.5] Seguindo as estatísticas de Over 2.5, com cinquenta e sete por cento de chances para over 2.5 gols, o mercado aponta para um jogo de média movimentação ofensiva. O Operario, jogando em casa, costuma pressionar mais, enquanto o America Mineiro busca contra-ataques. A tendência é de pelo menos três gols, mas sem excessos. [OFF] [FOCO: Over 3.5] Prosseguindo as estatísticas de Over 3.5, apenas vinte e três por cento de probabilidade para over 3.5 gols reforça a expectativa de um jogo equilibrado e de poucos gols. Ambas as equipes priorizam a solidez defensiva, especialmente em jogos decisivos da Série B. Um placar elástico é improvável, exigindo cautela do apostador. [OFF] [FOCO: Over 4.5] Chegando as estatísticas de Over 4.5, com meros onze por cento de chances, o over 4.5 gols é um cenário remoto. Para que isso ocorresse, seria necessário um colapso defensivo de um dos lados, algo raro entre times que brigam por posição na tabela. Apostar nesse mercado é praticamente especulativo. [OFF] [FOCO: BTTS] Observando as estatísticas de BTTS, ambas as equipes marcam em cinquenta e um por cento dos jogos, indicando um equilíbrio ofensivo. O Operario tem atuação consistente em casa, enquanto o America Mineiro possui poder de fogo para balançar as redes. A tendência é que cada time consiga ao menos um gol. [OFF] [FOCO: Vencer a Partida] Falando as estatísticas de Vencer a Partida, o Operario aparece como favorito com cinquenta por cento de chances de vitória, refletindo a força do mando de campo na Série B. O America Mineiro, com vinte e quatro por cento, depende de um jogo mais fechado. A estatística aponta para um triunfo magro dos donos da casa. [OFF] [FOCO: Chance Dupla] Notando as estatísticas de Chance Dupla, a chance dupla para Operario ou empate cobre setenta e seis por cento das possibilidades, sendo a escolha mais segura. O America Mineiro fora de casa tem desempenho irregular, e o Operario dificilmente perde diante de sua torcida. Essa aposta minimiza riscos em um jogo equilibrado. [OFF] [FOCO: HT] Finalizando as estatísticas de HT, setenta por cento de probabilidade de gol no primeiro tempo indica que as equipes começam pressionando. O Operario busca impor ritmo desde o início, enquanto o America tenta surpreender. Quem marcar primeiro terá vantagem tática, forçando o adversário a se expor no segundo tempo. [OFF] 
"""

# Locução limpa (removendo as tags)
texto_locucao = re.sub(r'\[.*?\]', '', texto_roteiro).replace('  ', ' ').strip()

# Salvar o texto limpo em um arquivo temporário para o leitor de áudio
caminho_texto_temp = "I:\\ROTEIRO VIDEOS\\AMERICA MG\\roteiro video\\roteiro_limpo_temp.txt"
with open(caminho_texto_temp, "w", encoding="utf-8") as f:
    f.write(texto_locucao)

# Salvar o Roteiro para a IA ler
caminho_roteiro = "I:\\ROTEIRO VIDEOS\\AMERICA MG\\roteiro video\\roteiro_teste_gols.txt"
with open(caminho_roteiro, "w", encoding="utf-8") as f:
    f.write(texto_roteiro)
print(f"Roteiro salvo em: {caminho_roteiro}")

# Gerar Áudio
caminho_audio = "I:\\ROTEIRO VIDEOS\\AMERICA MG\\roteiro video\\audio_teste_gols.mp3"
print("Gerando áudio Neural da Microsoft (Locutor: Antonio)...")

comando_tts = [
    ".\\venv\\Scripts\\edge-tts.exe",
    "--voice", "pt-BR-AntonioNeural",
    "--rate=+5%",
    "-f", caminho_texto_temp,
    "--write-media", caminho_audio
]
subprocess.run(comando_tts, check=True)
print(f"Áudio Neural salvo em: {caminho_audio}")

print("Iniciando gravação do Vídeo Modular (Novorizontino vs Vila Nova)...")
# Chama o script do playwright (assumindo que gerar_video.py aceita esses argumentos)
# url = "http://127.0.0.1:8000/pt-br/match/504696/cuiaba-vs-londrina/" # Cuiaba
subprocess.run([
    ".\\venv\\Scripts\\python.exe", "video_maker\\gerar_video.py", 
    "--url", match_url,
    "--audio", caminho_audio,
    "--roteiro", caminho_roteiro
], check=True)

print("Teste finalizado!")
