import json

with open(r'i:\GitHub\statsfut\statsfut\video_maker\StatsFut_Estudio.ipynb', 'r', encoding='utf-8') as f:
    nb = json.load(f)

for cell in nb['cells']:
    if cell['cell_type'] == 'code':
        source = "".join(cell['source'])
        
        # Remove a maldita regra que escondeu o titulo
        source = source.replace(".label-wrap { display: none !important; }", "")
        
        # Deixa o acordeon aberto por padrão para ele não precisar clicar
        source = source.replace('with gr.Accordion("⚙️ Status e Configurações Extras", open=False):', 'with gr.Accordion("⚙️ Configurações (Preencha o texto de referência abaixo!)", open=True):')
        
        cell['source'] = source.splitlines(True)
        break

with open(r'i:\GitHub\statsfut\statsfut\video_maker\StatsFut_Estudio.ipynb', 'w', encoding='utf-8') as f:
    json.dump(nb, f, indent=2)

print("Fixed!")
