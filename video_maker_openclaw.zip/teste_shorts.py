import os
import subprocess
import re

match_url = "http://127.0.0.1:8000/pt-br/match/504699/criciuma-vs-sao-bernardo/"

texto_roteiro = """
👇👇👇 TEXTO DO ÁUDIO (COPIE TUDO AQUI ABAIXO E COLE NO ELEVENLABS) 👇👇👇

Sabia que Criciúma vs São Bernardo tem 64% de chance de ter mais de 1.5 gols? O ataque visita é favorito, mas a defesa casa pode complicar. 64% de tendência para OVER 1.5 gols. O histórico mostra que os jogos do Criciúma e São Bernardo costumam ter pelo menos dois gols. É um padrão matemático forte. A aba GOLS indica São Bernardo como favorito (49%). Mas o empate tem apenas 14%. Se um time vencer, a chance é de 86%. Fique de olho nessa tendência de vitória.

👇👇👇 TEXTO DA MÁQUINA (COPIE TUDO AQUI ABAIXO E COLE NO ARQUIVO roteiro.txt) 👇👇👇

[ABA: gols] Sabia que Criciúma vs São Bernardo tem 64% de chance de ter mais de 1.5 gols? O ataque visita é favorito, mas a defesa casa pode complicar. [FOCO: Over 1.5] 64% de tendência para OVER 1.5 gols. O histórico mostra que os jogos do Criciúma e São Bernardo costumam ter pelo menos dois gols. É um padrão matemático forte. [OFF] [FOCO: Vencedor da Partida] A aba GOLS indica São Bernardo como favorito (49%). Mas o empate tem apenas 14%. Se um time vencer, a chance é de 86%. Fique de olho nessa tendência de vitória. [OFF]
"""

# Extrai apenas o áudio limpo da primeira metade
texto_locucao = texto_roteiro.split("👇👇👇 TEXTO DA MÁQUINA")[0].replace("👇👇👇 TEXTO DO ÁUDIO (COPIE TUDO AQUI ABAIXO E COLE NO ELEVENLABS) 👇👇👇", "").strip()

# Salvar o texto limpo em um arquivo temporário para o leitor de áudio
caminho_texto_temp = "I:\\ROTEIRO VIDEOS\\AMERICA MG\\roteiro video\\roteiro_shorts_limpo_temp.txt"
with open(caminho_texto_temp, "w", encoding="utf-8") as f:
    f.write(texto_locucao)

# Salvar o Roteiro para a IA ler
caminho_roteiro = "I:\\ROTEIRO VIDEOS\\AMERICA MG\\roteiro video\\roteiro_teste_shorts.txt"
with open(caminho_roteiro, "w", encoding="utf-8") as f:
    f.write(texto_roteiro)
print(f"Roteiro Shorts salvo em: {caminho_roteiro}")

# Gerar Áudio (Mais rápido para simular TikTok)
caminho_audio = "I:\\ROTEIRO VIDEOS\\AMERICA MG\\roteiro video\\audio_teste_shorts.mp3"
print("Gerando áudio acelerado para TikTok (Locutor: Antonio)...")

comando_tts = [
    ".\\venv\\Scripts\\edge-tts.exe",
    "--voice", "pt-BR-AntonioNeural",
    "--rate=+20%",  # Áudio de shorts é acelerado!
    "-f", caminho_texto_temp,
    "--write-media", caminho_audio
]
subprocess.run(comando_tts, check=True)
print(f"Áudio Shorts salvo em: {caminho_audio}")

print("Iniciando gravação do Short Vertical (1080x1920)...")
subprocess.run([
    ".\\venv\\Scripts\\python.exe", "video_maker\\gerar_video_curto.py", 
    "--url", match_url,
    "--audio", caminho_audio,
    "--roteiro", caminho_roteiro
], check=True)

print("Teste Shorts finalizado!")
