import os
import json
import shutil
import subprocess
import argparse

# ==============================================================================
# SCRIPT 100% INDEPENDENTE - SKILL KAGGLE
# Este script lê o kaggle.json, monta o notebook e dá a partida na GPU do Kaggle!
# ==============================================================================

def ligar_motor_kaggle(idioma: str):
    base_dir = r"i:\GitHub\statsfut\statsfut"
    factory_dir = os.path.join(base_dir, "video_maker", "openclaw_factory")
    build_dir = os.path.join(factory_dir, "kaggle_build")
    
    # 1. Configurar Autenticação (aponta para a pasta onde está o kaggle.json)
    os.environ['KAGGLE_CONFIG_DIR'] = factory_dir
    
    # Lendo o username do kaggle.json para criar o ID
    with open(os.path.join(factory_dir, "kaggle.json"), "r") as f:
        kaggle_creds = json.load(f)
        username = kaggle_creds["username"]
        
    print(f"[OpenClaw] Autenticado como Kaggle User: {username}")
    
    # 2. Selecionar o arquivo de código correto baseado no idioma
    arquivos = {
        "pt": "003 - Kaggle_Estudio_v2_pt-BR (Sistema Anti-Dormida).txt",
        "en": "004 - Kaggle_Estudio_v2_EN (Sistema Anti-Dormida).txt",
        "es": "005 - Kaggle_Estudio_v2_ES (Sistema Anti-Dormida).txt"
    }
    
    arquivo_origem = os.path.join(factory_dir, arquivos.get(idioma.lower(), arquivos["pt"]))
    
    if not os.path.exists(arquivo_origem):
        print(f"[Erro] Arquivo de código não encontrado: {arquivo_origem}")
        return False
        
    print(f"[OpenClaw] Preparando motor em idioma: {idioma.upper()}")
    
    # 3. Criar a pasta de "Build" temporária
    os.makedirs(build_dir, exist_ok=True)
    
    # 4. Copiar o código para o nome oficial que o Kaggle vai ler
    codigo_destino = os.path.join(build_dir, "statsfut_estudio.py")
    shutil.copy2(arquivo_origem, codigo_destino)
    
    # 5. Criar o arquivo de Meta-dados (As regras do servidor Kaggle)
    metadata = {
      "id": f"{username}/statsfut-estudio-voz",
      "title": "StatsFut Estudio de Voz GPU",
      "code_file": "statsfut_estudio.py",
      "language": "python",
      "kernel_type": "script",
      "is_private": "true",
      "enable_gpu": "true",
      "enable_internet": "true",
      "dataset_sources": [],
      "competition_sources": [],
      "kernel_sources": []
    }
    
    with open(os.path.join(build_dir, "kernel-metadata.json"), "w") as f:
        json.dump(metadata, f, indent=2)
        
    print("[OpenClaw] Empacotamento concluído. Disparando comando para os servidores do Kaggle...")
    
    # 6. Disparar a Inicialização (Push API)
    try:
        # Se a biblioteca kaggle não estiver instalada, instalamos rapidamente na hora
        subprocess.run(["pip", "install", "-q", "kaggle"], check=False)
        
        # O comando mágico que liga a GPU
        resultado = subprocess.run(
            ["kaggle", "kernels", "push", "-p", build_dir],
            capture_output=True, text=True, check=True
        )
        print("[OpenClaw] SUCESSO! A máquina do Kaggle está ligando em Background.")
        print(resultado.stdout)
        print("-> Em cerca de 1 a 2 minutos, o Kaggle enviará o link para o seu site automaticamente!")
        return True
    except subprocess.CalledProcessError as e:
        print("[Erro] O Kaggle rejeitou o comando:")
        print(e.stderr)
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Skill do OpenClaw para ligar o Motor do Kaggle")
    parser.add_argument("--idioma", type=str, choices=['pt', 'en', 'es'], default='pt', help="Idioma do estúdio de voz")
    args = parser.parse_args()
    
    ligar_motor_kaggle(args.idioma)
