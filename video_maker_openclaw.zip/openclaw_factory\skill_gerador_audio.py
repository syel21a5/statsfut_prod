import os
import requests
import time
import argparse
from typing import Dict, Any

# ==============================================================================
# SCRIPT 100% INDEPENDENTE - NÃO AFETA A FÁBRICA MANUAL
# Este script é apenas um "controle remoto" que aperta o botão do seu site.
# ==============================================================================

def disparar_geracao_audio(match_id: int, base_url: str = "http://127.0.0.1:8000") -> Dict[str, Any]:
    """
    Faz uma requisição para a API do StatsFut para disparar a geração de voz via Kaggle.
    """
    url = f"{base_url}/api/generate-match-audio/{match_id}/"
    print(f"[OpenClaw Skill] Solicitando áudio para o jogo {match_id} em {url}...")
    
    try:
        response = requests.post(url, timeout=10)
        data = response.json()
        
        if response.status_code == 200 and data.get('status') == 'success':
            task_id = data.get('task_id')
            print(f"[OpenClaw Skill] Tarefa iniciada com sucesso! Task ID: {task_id}")
            return {"status": "success", "task_id": task_id}
        else:
            print(f"[OpenClaw Skill] Erro na requisição: {data}")
            return {"status": "error", "message": data.get('message', 'Erro desconhecido')}
            
    except Exception as e:
        print(f"[OpenClaw Skill] Falha de conexão: {str(e)}")
        return {"status": "error", "message": str(e)}

def checar_status_audio(task_id: str, base_url: str = "http://127.0.0.1:8000", timeout_secs: int = 120) -> str:
    """
    Fica perguntando ao servidor se o áudio já ficou pronto (Polling).
    """
    url = f"{base_url}/api/generate-match-audio/status/{task_id}/"
    start_time = time.time()
    
    print(f"[OpenClaw Skill] Aguardando Kaggle processar o áudio (Task: {task_id})...")
    
    while time.time() - start_time < timeout_secs:
        try:
            response = requests.get(url, timeout=5)
            data = response.json()
            status = data.get('status')
            
            if status == 'success':
                audio_url = data.get('audio_url')
                print(f"[OpenClaw Skill] ÁUDIO PRONTO! URL: {audio_url}")
                return audio_url
            elif status == 'error':
                print(f"[OpenClaw Skill] Kaggle retornou um erro: {data.get('message')}")
                return None
                
            # Se ainda estiver processando, espera 5 segundos e tenta de novo
            time.sleep(5)
            
        except Exception as e:
            print(f"[OpenClaw Skill] Erro ao checar status: {str(e)}")
            time.sleep(5)
            
    print("[OpenClaw Skill] Tempo limite esgotado esperando o Kaggle.")
    return None

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Skill do OpenClaw para gerar áudio via Kaggle")
    parser.add_argument("--match_id", type=int, required=True, help="ID da partida no banco de dados")
    parser.add_argument("--base_url", type=str, default="http://127.0.0.1:8000", help="URL do site StatsFut")
    
    args = parser.parse_args()
    
    # Executa o fluxo completo
    resultado = disparar_geracao_audio(args.match_id, args.base_url)
    
    if resultado['status'] == 'success':
        audio_final_url = checar_status_audio(resultado['task_id'], args.base_url)
        if audio_final_url:
            print(f"SUCESSO_FINAL_URL: {audio_final_url}")
