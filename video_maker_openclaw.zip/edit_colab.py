import json
import re

file_path = r'i:\GitHub\statsfut\statsfut\video_maker\clonador.ipynb'
with open(file_path, 'r', encoding='utf-8') as f:
    nb = json.load(f)

# Find the code cell
code_cell = None
for cell in nb['cells']:
    if cell['cell_type'] == 'code':
        code_cell = cell
        break

code_text = ''.join(code_cell['source'])

# 1. CSS
new_css = """
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
        * { font-family: 'Inter', sans-serif !important; }
        
        body, .gradio-container { 
            background-color: #0f172a !important;
            color: #ffffff !important; 
        }
        
        .gradio-container .form { background: transparent !important; border: none !important; box-shadow: none !important; }
        .label-wrap { display: none !important; } 
        
        /* --- CAIXA DE TEXTO (Esquerda) --- */
        #caixa-texto {
            position: relative;
            background: #1e293b !important;
            border-radius: 12px !important;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3) !important;
            height: 100% !important;
        }
        #caixa-texto::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; height: 5px;
            background: #ea580c;
            z-index: 10;
        }
        #caixa-texto textarea {
            background: transparent !important;
            border: none !important;
            color: #f8fafc !important;
            font-size: 16px !important;
            padding: 30px 25px !important;
            resize: none !important;
            box-shadow: none !important;
            min-height: 250px !important;
        }
        #caixa-texto textarea:focus { outline: none !important; border: none !important; }
        
        /* --- COLUNA DIREITA --- */
        #coluna-direita {
            display: flex !important;
            flex-direction: column !important;
            justify-content: space-between !important; 
            height: 100% !important;
        }
        
        #caixa-audio { border: none !important; background: transparent !important; margin-bottom: 10px !important; }
        #caixa-audio .upload-container {
            background: #1e293b !important;
            border: 1px solid #334155 !important;
            border-radius: 8px !important;
            min-height: 55px !important;
            height: 55px !important;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.2s;
        }
        #caixa-audio .upload-container:hover { background: #334155 !important; }
        
        #caixa-linguagem .wrap {
            background: #1e293b !important;
            border: 1px solid #334155 !important;
            border-radius: 8px !important;
            color: #f8fafc !important;
        }
        
        #botao-gerar {
            background: #ea580c !important;
            border: none !important;
            border-radius: 8px !important;
            color: white !important;
            font-weight: bold !important;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 15px !important;
            box-shadow: 0 4px 6px rgba(234, 88, 12, 0.3) !important;
            transition: all 0.2s;
            margin-top: 15px !important; 
            width: 100% !important;
        }
        #botao-gerar:hover { background: #c2410c !important; }
        
        #botao-gerar:disabled {
            background: #475569 !important;
            color: #94a3b8 !important;
            cursor: not-allowed !important;
            box-shadow: none !important;
        }

        /* --- ÁUDIO RESULTADO --- */
        #caixa-resultado { margin-top: 20px !important; }
"""
code_text = re.sub(r'CSS = """[\s\S]*?"""', f'CSS = """{new_css}"""', code_text)

# 2. BRAND HTML
new_brand = """
        BRAND_HTML = \"\"\"
        <div style="text-align: center; margin-bottom: 30px; margin-top: 20px;">
            <h1 style="color: white; margin: 0; font-size: 28px; font-weight: bold;">🎙️ Clonador de Voz - <span style="color: #ea580c">StatsFut</span></h1>
            <p style="color: #94a3b8; font-size: 15px; font-weight: 400; margin: 8px 0 0 0;">Fábrica de Vídeos Automática</p>
        </div>
        \"\"\"
"""
code_text = re.sub(r'BRAND_HTML = """[\s\S]*?"""', new_brand.strip(), code_text)

# 3. Audio generation MP3 saving
mp3_logic = """
            waveform = audio[0].squeeze() 
            if hasattr(waveform, 'numpy'):
                waveform = waveform.numpy()
            waveform = (waveform * 32767).astype(np.int16)
            
            import scipy.io.wavfile
            from pydub import AudioSegment
            import time
            import os
            
            os.makedirs('/tmp', exist_ok=True)
            wav_path = '/tmp/temp_audio.wav'
            scipy.io.wavfile.write(wav_path, sampling_rate, waveform)
            
            mp3_path = f'/tmp/Audio_StatsFut_{int(time.time())}.mp3'
            AudioSegment.from_wav(wav_path).export(mp3_path, format="mp3", bitrate="192k")
            
            return mp3_path, f"✅ Áudio MP3 Gerado com Sucesso! ({waveform.shape[-1]/sampling_rate:.1f}s)"
"""
code_text = re.sub(r'waveform = audio\[0\]\.squeeze\(\)[\s\S]*?return \(sampling_rate, waveform\), f"✅ Generated.*"', mp3_logic.strip(), code_text)

# 4. Change gradio outputs to type='filepath'
code_text = code_text.replace('type="numpy", \n                                elem_id="caixa-resultado"', 'type="filepath", \n                                elem_id="caixa-resultado"')

# 5. Fix PIP install to include scipy
code_text = code_text.replace('"pydub", "gradio==6.11.0"', '"pydub", "scipy", "gradio==6.11.0"')

# 6. Change markdown cell
nb['cells'][0]['source'] = [
    "<div style='text-align: center; padding: 30px; background: #0f172a; border: 2px solid #ea580c; border-radius: 15px; margin: 10px 0; box-shadow: 0 10px 30px rgba(234, 88, 12, 0.2); font-family: sans-serif;'>\n",
    "  <h1 style='color: white; margin: 0 0 8px 0; font-size: 2.5em;'>🎙️ Clonador de Voz MP3</h1>\n",
    "  <h3 style='color: #ea580c; margin: 0 0 15px 0; font-weight: 400;'><strong>StatsFut - Fábrica de Vídeos</strong></h3>\n",
    "</div>\n",
    "\n",
    "> ⚠️ Certifique-se de selecionar **Ambiente de execução → Alterar o tipo de ambiente de execução → T4 GPU** antes de rodar."
]

# Update code cell properly
code_cell['source'] = code_text.splitlines(True)

with open(r'i:\GitHub\statsfut\statsfut\video_maker\StatsFut_Clonador.ipynb', 'w', encoding='utf-8') as f:
    json.dump(nb, f, indent=2)

print('Done')
