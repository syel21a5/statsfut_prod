import os
import sys
import re
import whisper

sys.path.insert(0, os.path.abspath('i:\\GitHub\\statsfut\\statsfut'))

roteiro_text = """
Vamos analisar o mercado de gols desta partida. 
[FOCO: 68%] Começando pelo Over 1.5 gols, temos sessenta e oito por cento de chance. [OFF] 
[FOCO: 42%] Avançando para o Over 2.5 gols, a probabilidade cai para quarenta e dois por cento. [OFF] 
[FOCO: 18%] Enquanto isso, o Over 3.5 gols tem apenas dezoito por cento de chance. [OFF] 
[FOCO: 7%] Indo para o Over 4.5 gols, a linha é ainda mais improvável, com apenas sete por cento. [OFF] 
[FOCO: 47%] Analisando o mercado de ambas marcam, temos quarenta e sete por cento de chance do sim. [OFF] 
[FOCO: Vencer] Falando sobre o resultado, a melhor aposta para vencer a partida é o empate. [OFF] 
[FOCO: Chance Dupla] Destacando a chance dupla, o visitante tem oitenta e nove por cento de segurança. [OFF] 
[FOCO: 63%] Concluindo com a probabilidade de gol no primeiro tempo, temos sessenta e três por cento. [OFF]
"""

audio_path = "I:\\ROTEIRO VIDEOS\\AMERICA MG\\roteiro video\\audio_teste_gols.mp3"
model = whisper.load_model("tiny", download_root="E:\\WHISPER_MODELS")
result = model.transcribe(audio_path, word_timestamps=True, language="pt")

audio_words = []
for segment in result['segments']:
    for word in segment.get('words', []):
        clean = re.sub(r'[^\w\s]', '', word['word'].lower().strip())
        if clean:
            audio_words.append({
                "text": clean,
                "start": word['start'],
                "end": word['end']
            })

tags = []
for match in re.finditer(r'\[(.*?)\]', roteiro_text):
    tag_content = match.group(1).strip()
    tag_start = match.start()
    tag_end = match.end()
    
    is_off = (tag_content.upper() == 'OFF')
    foco_text = ""
    anchor_words = []
    full_words_after = []
    
    if tag_content.upper().startswith('FOCO:'):
        foco_text = tag_content[5:].strip()
        text_after = roteiro_text[tag_end:]
        full_words_after = text_after.split()[:15]
        words_after = [w for w in re.sub(r'[^\w\s]', '', text_after.lower()).split() if len(w) > 1]
        if words_after:
            anchor_words = words_after[:5]
            
    tags.append({
        "content": tag_content,
        "is_off": is_off,
        "foco_text": foco_text,
        "anchor_words": anchor_words,
        "full_words_after": full_words_after,
        "char_idx": tag_start
    })

search_start_idx = 0

for i, t in enumerate(tags):
    tag_content = t["content"]
    is_off = t["is_off"]
    foco_text = t["foco_text"]
    anchor_words = t["anchor_words"]
    full_words_after = t["full_words_after"]
    
    if is_off or tag_content.upper().startswith('ABA:'):
        continue
        
    best_idx = -1
    matched_word = ""
    if anchor_words:
        for aw in anchor_words:
            lookahead = min(search_start_idx + 25, len(audio_words))
            for j in range(search_start_idx, lookahead):
                w = audio_words[j]['text']
                if aw == w or (len(aw) > 3 and aw in w):
                    best_idx = j
                    matched_word = aw
                    break
            if best_idx != -1:
                break
                
    event_time = 0.0
    if best_idx != -1:
        clean_full_words = [re.sub(r'[^\w\s]', '', w.lower()) for w in full_words_after]
        aw_offset = 0
        for k, cw in enumerate(clean_full_words):
            if not cw: continue
            if cw == matched_word or (len(matched_word) > 3 and matched_word in cw):
                aw_offset = k
                break
                
        start_idx = max(search_start_idx, best_idx - aw_offset)
        event_time = audio_words[start_idx]['start']
        
        print(f"[{foco_text}] Matched '{matched_word}' at idx {best_idx} ({audio_words[best_idx]['start']}s). Offset: -{aw_offset} words. Actual start word: '{audio_words[start_idx]['text']}' at {event_time}s")
        search_start_idx = best_idx + 1

