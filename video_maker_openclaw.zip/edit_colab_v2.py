import json
import re

file_path = r'i:\GitHub\statsfut\statsfut\video_maker\clonador.ipynb'
with open(file_path, 'r', encoding='utf-8') as f:
    nb = json.load(f)

# Find the code cell
code_cell = None
for cell in nb['cells']:
    if cell['cell_type'] == 'code':
        code_cell = cell
        break

code_text = ''.join(code_cell['source'])

# 1. CSS - ELEVENLABS LIGHT THEME
new_css = """
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap');
        * { font-family: 'Inter', sans-serif !important; }
        
        body, .gradio-container { 
            background-color: #f9fafb !important;
            background-image: none !important;
            color: #111827 !important; 
        }
        
        .gradio-container .form { background: transparent !important; border: none !important; box-shadow: none !important; }
        .label-wrap { display: none !important; } 
        
        /* --- CAIXA DE TEXTO (Esquerda) --- */
        #caixa-texto {
            position: relative;
            background: #ffffff !important;
            border-radius: 12px !important;
            border: 1px solid #e5e7eb !important;
            overflow: hidden;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06) !important;
            height: 100% !important;
        }
        #caixa-texto textarea {
            background: transparent !important;
            border: none !important;
            color: #111827 !important;
            font-size: 16px !important;
            padding: 30px 25px !important;
            resize: none !important;
            box-shadow: none !important;
            min-height: 250px !important;
        }
        #caixa-texto textarea:focus { outline: none !important; border: none !important; }
        
        /* --- COLUNA DIREITA --- */
        #coluna-direita {
            display: flex !important;
            flex-direction: column !important;
            justify-content: space-between !important; 
            height: 100% !important;
        }
        
        #caixa-audio { border: none !important; background: transparent !important; margin-bottom: 10px !important; }
        #caixa-audio .upload-container {
            background: #ffffff !important;
            border: 1px solid #e5e7eb !important;
            border-radius: 8px !important;
            min-height: 55px !important;
            height: 55px !important;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #111827 !important;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05) !important;
            transition: all 0.2s;
        }
        #caixa-audio .upload-container:hover { border-color: #d1d5db !important; }
        
        /* Fix text colors inside gradio widgets */
        .gr-text-input, .gr-box, .gr-input {
            color: #111827 !important;
            background: #ffffff !important;
            border-color: #e5e7eb !important;
        }
        
        #caixa-linguagem .wrap, #caixa-linguagem select {
            background: #ffffff !important;
            border: 1px solid #e5e7eb !important;
            border-radius: 8px !important;
            color: #111827 !important;
            box-shadow: 0 1px 2px 0 rgba(0, 0, 0, 0.05) !important;
        }
        
        #botao-gerar {
            background: #000000 !important;
            border: none !important;
            border-radius: 8px !important;
            color: white !important;
            font-weight: 600 !important;
            padding: 15px !important;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1) !important;
            transition: all 0.2s;
            margin-top: 15px !important; 
            width: 100% !important;
        }
        #botao-gerar:hover { background: #1f2937 !important; }
        
        #botao-gerar:disabled {
            background: #e5e7eb !important;
            color: #9ca3af !important;
            cursor: not-allowed !important;
            box-shadow: none !important;
        }

        /* --- ÁUDIO RESULTADO --- */
        #caixa-resultado { margin-top: 20px !important; }
        #caixa-resultado .wrap, #caixa-resultado audio {
            background: #ffffff !important;
            border-radius: 40px !important;
            border: 1px solid #e5e7eb !important;
            padding: 5px 10px !important;
        }
        
        /* Ajuste do acordeon de configurações */
        .gr-accordion {
            background: #ffffff !important;
            border: 1px solid #e5e7eb !important;
            color: #111827 !important;
        }
        .gr-accordion * { color: #111827 !important; }
"""
code_text = re.sub(r'CSS = """[\s\S]*?"""', f'CSS = """{new_css}"""', code_text)

# 2. BRAND HTML
new_brand = """
        BRAND_HTML = \"\"\"
        <div style="text-align: center; margin-bottom: 40px; margin-top: 20px;">
            <h1 style="color: #111827; margin: 0; font-size: 32px; font-weight: 600; letter-spacing: -0.5px;">Vozes Sintéticas <span style="color: #ea580c">StatsFut</span></h1>
            <p style="color: #6b7280; font-size: 16px; font-weight: 400; margin: 8px 0 0 0;">Crie áudios perfeitos com clonagem instantânea.</p>
        </div>
        \"\"\"
"""
code_text = re.sub(r'BRAND_HTML = """[\s\S]*?"""', new_brand.strip(), code_text)

# 3. Audio generation MP3 saving
mp3_logic = """
            waveform = audio[0].squeeze() 
            if hasattr(waveform, 'numpy'):
                waveform = waveform.numpy()
            waveform = (waveform * 32767).astype(np.int16)
            
            import scipy.io.wavfile
            from pydub import AudioSegment
            import time
            import os
            
            os.makedirs('/tmp', exist_ok=True)
            wav_path = '/tmp/temp_audio.wav'
            scipy.io.wavfile.write(wav_path, sampling_rate, waveform)
            
            mp3_path = f'/tmp/Audio_StatsFut_{int(time.time())}.mp3'
            AudioSegment.from_wav(wav_path).export(mp3_path, format="mp3", bitrate="192k")
            
            return mp3_path, f"✅ Áudio gerado com sucesso! Clique no ícone de Download."
"""
code_text = re.sub(r'waveform = audio\[0\]\.squeeze\(\)[\s\S]*?return \(sampling_rate, waveform\), f"✅ Generated.*"', mp3_logic.strip(), code_text)

# 4. Change gradio outputs to type='filepath'
code_text = code_text.replace('type="numpy", \n                                elem_id="caixa-resultado"', 'type="filepath", \n                                elem_id="caixa-resultado"')

# 5. Fix PIP install to include scipy
code_text = code_text.replace('"pydub", "gradio==6.11.0"', '"pydub", "scipy", "gradio==6.11.0"')

# 6. Pre-load Audio trick (Download audio from github if it exists, or just explain how to mount Drive)
setup_drive_code = """
        import subprocess
        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--upgrade", "transformers>=5.3"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        # Baixar uma voz padrão se existir no repositório (Opcional)
        try:
            subprocess.run(["wget", "-q", "-O", "/content/voz_padrao.mp3", "https://raw.githubusercontent.com/syel21a5/statsfut_prod/main/video_maker/voz_padrao.mp3"])
        except:
            pass
"""
code_text = code_text.replace('import subprocess\n        subprocess.run([sys.executable, "-m", "pip", "install", "-q", "--upgrade", "transformers>=5.3"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)', setup_drive_code.strip())

# Set default value in gr.Audio if downloaded
audio_ui = """
                            vc_ref_audio = gr.Audio(
                                value="/content/voz_padrao.mp3" if os.path.exists("/content/voz_padrao.mp3") else None,
                                label="🎙️ Voz Original (Upload)",
                                type="filepath", 
                                elem_id="caixa-audio"
                            )
"""
code_text = re.sub(r'vc_ref_audio = gr\.Audio\([\s\S]*?elem_id="caixa-audio"\n\s*\)', audio_ui.strip(), code_text)


# Also auto-fill the reference text if needed, or clarify
ref_text_ui = """
                        vc_ref_text = gr.Textbox(
                            label="O que a pessoa está dizendo no áudio de upload? (IMPORTANTE)", lines=2,
                            placeholder="Escreva EXATAMENTE as palavras do áudio original aqui para evitar que a IA invente palavras no começo."
                        )
"""
code_text = re.sub(r'vc_ref_text = gr\.Textbox\([\s\S]*?placeholder="Transcript.*?"\n\s*\)', ref_text_ui.strip(), code_text)

# 7. Change markdown cell
nb['cells'][0]['source'] = [
    "<div style='text-align: center; padding: 40px; background: #ffffff; border: 1px solid #e5e7eb; border-radius: 12px; margin: 10px 0; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1); font-family: sans-serif;'>\n",
    "  <h1 style='color: #111827; margin: 0 0 8px 0; font-size: 2.5em; font-weight: 600;'>🎙️ Estúdio de Locução</h1>\n",
    "  <h3 style='color: #ea580c; margin: 0 0 15px 0; font-weight: 500;'><strong>StatsFut Premium</strong></h3>\n",
    "</div>\n",
    "\n",
    "> ⚠️ **Passo 1:** No menu superior, clique em **Ambiente de execução → Alterar o tipo de ambiente de execução** e escolha **T4 GPU**.\n",
    "> ⚠️ **Passo 2:** Aperte o botão de Play (▶) na célula abaixo e aguarde o link aparecer."
]

# Update code cell properly
code_cell['source'] = code_text.splitlines(True)

with open(r'i:\GitHub\statsfut\statsfut\video_maker\StatsFut_Estudio.ipynb', 'w', encoding='utf-8') as f:
    json.dump(nb, f, indent=2)

print('Done')
