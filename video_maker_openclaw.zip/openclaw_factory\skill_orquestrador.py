import os
import sys
import argparse
import subprocess
import requests

# ==============================================================================
# SCRIPT 100% INDEPENDENTE - O CÉREBRO DA FÁBRICA DE VÍDEOS (ORQUESTRADOR)
# Este script chama as outras Skills na ordem correta e gera o vídeo final!
# ==============================================================================

def orquestrar_fabrica(match_url: str, idioma: str, formato: str, abas: str, base_url: str):
    import re
    # Extrair o ID do jogo a partir da URL (ex: https://statsfut.com/pt-br/match/478826/...)
    match = re.search(r'/match/(\d+)', match_url)
    if not match:
        print("❌ URL inválida. Não foi possível encontrar o ID do jogo na URL.")
        return
    match_id = int(match.group(1))
    
    print(f"\n{'='*50}")
    print(f"🎬 INICIANDO FÁBRICA DE VÍDEOS OPENCLAW")
    print(f"URL: {match_url}")
    print(f"ID Extraído: {match_id} | Idioma: {idioma.upper()} | Formato: {formato}")
    print(f"{'='*50}\n")
    
    diretorio_atual = os.path.dirname(os.path.abspath(__file__))
    pasta_video_maker = os.path.dirname(diretorio_atual)
    
    # 1. LIGAR O KAGGLE
    print("\n[ETAPA 1] Ligando a GPU do Kaggle...")
    skill_kaggle = os.path.join(diretorio_atual, "skill_ligar_kaggle.py")
    subprocess.run([sys.executable, skill_kaggle, "--idioma", idioma])
    
    # 2. GERAR ROTEIRO E SALVAR TEXTO
    print("\n[ETAPA 2] Gerando Roteiro com a IA do StatsFut...")
    skill_roteiro = os.path.join(diretorio_atual, "skill_gerador_roteiro.py")
    roteiro_path = os.path.join(pasta_video_maker, "roteiro_ia_temp.txt")
    
    resultado_roteiro = subprocess.run([
        sys.executable, skill_roteiro, 
        "--match_id", str(match_id), 
        "--formato", formato, 
        "--abas", abas, 
        "--base_url", base_url,
        "--saida", roteiro_path
    ])
    
    if resultado_roteiro.returncode != 0 or not os.path.exists(roteiro_path):
        print("❌ Falha na geração do roteiro. Abortando a fábrica.")
        return
        
    # 3. GERAR O ÁUDIO NO KAGGLE
    print("\n[ETAPA 3] Solicitando Áudio e Clonagem de Voz...")
    skill_audio = os.path.join(diretorio_atual, "skill_gerador_audio.py")
    
    # O skill de audio imprime "SUCESSO_FINAL_URL: https://..." no final
    processo_audio = subprocess.run([
        sys.executable, skill_audio, 
        "--match_id", str(match_id), 
        "--base_url", base_url
    ], capture_output=True, text=True)
    
    print(processo_audio.stdout)
    
    audio_url = None
    for linha in processo_audio.stdout.split('\n'):
        if "SUCESSO_FINAL_URL:" in linha:
            audio_url = linha.split("SUCESSO_FINAL_URL:")[1].strip()
            
    if not audio_url:
        print("❌ Falha na geração do áudio. Abortando a fábrica.")
        return
        
    print(f"✅ Áudio recebido do Kaggle: {audio_url}")
    
    # Baixar o áudio para o disco local
    audio_path = os.path.join(pasta_video_maker, "audio_temp.mp3")
    print("Baixando o arquivo de áudio...")
    r = requests.get(audio_url)
    with open(audio_path, 'wb') as f:
        f.write(r.content)
        
    # 4. RODAR O SEU GERAR_VIDEO.PY
    print("\n[ETAPA 4] Gravando a Tela e Montando o Vídeo (Sua Fábrica Original!)...")
    
    # Executa o SEU script original intacto, repassando a URL exata que você forneceu!
    script_gerar_video = os.path.join(pasta_video_maker, "gerar_video.py")
    
    comando_video = [
        sys.executable, script_gerar_video,
        "--url", match_url,
        "--audio", audio_path,
        "--roteiro", roteiro_path
    ]
    
    print(f"Executando comando: {' '.join(comando_video)}")
    subprocess.run(comando_video, cwd=pasta_video_maker)
    
    print(f"\n{'='*50}")
    print(f"🎉 VÍDEO CONCLUÍDO COM SUCESSO PELA INTELIGÊNCIA ARTIFICIAL!")
    print(f"{'='*50}\n")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--match_url", type=str, required=True, help="Cole o link completo do jogo aqui (Ex: https://statsfut.com/.../match/12345/...)")
    parser.add_argument("--idioma", type=str, choices=['pt', 'en', 'es'], default='pt')
    parser.add_argument("--formato", type=str, choices=['short', 'long'], default='short')
    parser.add_argument("--abas", type=str, default='gols,escanteios,chutes')
    parser.add_argument("--base_url", type=str, default="http://127.0.0.1:8000")
    
    args = parser.parse_args()
    orquestrar_fabrica(args.match_url, args.idioma, args.formato, args.abas, args.base_url)
