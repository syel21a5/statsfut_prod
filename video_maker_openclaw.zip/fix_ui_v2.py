import json
import re

with open(r'i:\GitHub\statsfut\statsfut\video_maker\StatsFut_Estudio.ipynb', 'r', encoding='utf-8') as f:
    nb = json.load(f)

for cell in nb['cells']:
    if cell['cell_type'] == 'code':
        source = "".join(cell['source'])
        
        # Substitui a regra de fundo do body e container para centralizar e dar cara de "App" (Estilo ElevenLabs)
        new_css_block = """
        body { 
            background-color: #f3f4f6 !important; /* Fundo cinza clarinho */
            color: #111827 !important; 
        }
        
        .gradio-container { 
            max-width: 1100px !important; /* Restringe a largura pra não ocupar a tela toda */
            margin: 40px auto !important; /* Centraliza na tela com espacamento superior */
            background-color: #ffffff !important; /* Fundo branco do cartao principal */
            border-radius: 20px !important;
            padding: 40px !important;
            box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.05), 0 10px 10px -5px rgba(0, 0, 0, 0.02) !important;
            border: 1px solid #e5e7eb !important;
        }
        """
        
        # Encontra a definicao antiga de body e gradio-container e substitui
        source = re.sub(r'body, \.gradio-container \{[^}]+\}', new_css_block.strip(), source)
        
        cell['source'] = source.splitlines(True)
        break

with open(r'i:\GitHub\statsfut\statsfut\video_maker\StatsFut_Estudio.ipynb', 'w', encoding='utf-8') as f:
    json.dump(nb, f, indent=2)

print("CSS atualizado!")
