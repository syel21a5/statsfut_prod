import os
import subprocess
import re

match_url = "http://127.0.0.1:8000/pt-br/match/504699/criciuma-vs-sao-bernardo/"

texto_roteiro = """
[ABA: escanteios] Criciúma e São Bernardo prometem um duelo de pontas intenso na Série B, com média de vinte e três vírgula quatro escanteios por jogo na competição. O time da casa busca impor seu ritmo ofensivo pelos lados do campo, enquanto o visitante deve explorar contra-ataques para gerar bolas paradas e inflar esse mercado. [FOCO: Over 7.5] Mergulhando o mercado de Over 7.5, a linha de over sete vírgula cinco cantos apresenta impressionantes oitenta e nove por cento de ocorrência nas partidas da Série B, indicando uma tendência fortíssima. Para o confronto entre Criciúma e São Bernardo, as características de cruzamentos e disputas físicas sugerem que essa barreira será superada com certa naturalidade no decorrer dos noventa minutos. [OFF] [FOCO: Over 8.5] Caminhando o mercado de Over 8.5, com oitenta e dois por cento dos jogos ultrapassando oito vírgula cinco escanteios, a estatística reforça um cenário de alta atividade nas laterais. A tendência de pressão do Criciúma atuando em casa, combinada com a transição rápida do São Bernardo, cria um ambiente propício para que essa linha seja atingida antes mesmo do intervalo. [OFF] [FOCO: Over 9.5] Analisando o mercado de Over 9.5, a linha principal de nove vírgula cinco cantos é superada em setenta e seis por cento das partidas, consolidando-se como um patamar sólido no campeonato. A necessidade de ambos os times em buscar o ataque, especialmente o Criciúma para furar a defesa adversária, deve garantir um número confortável de escanteios para quem aposta nesse mercado. [OFF] [FOCO: Over 10.5] Olhando o mercado de Over 10.5, atingir dez vírgula cinco escanteios representa um cenário de alta pressão, com sessenta e cinco por cento de aproveitamento na Série B. Para este jogo, a chance aumenta se o placar estiver apertado, forçando o São Bernardo a se expor mais nos minutos finais e o Criciúma a bombardear a área rival. [OFF] [FOCO: Base do Jogo] Pegando o mercado de Base do Jogo, a base do jogo, com média de vinte e três vírgula quatro escanteios totais, aponta para uma partida movimentada nas laterais. Esse número elevado sugere que ambas as equipes priorizam jogadas pelos flancos e cruzamentos, o que torna o mercado de cantos um dos mais atrativos para análise tática e investimento neste confronto da Série B. [OFF] [FOCO: Melhor Palpite] Filtrando o mercado de Melhor Palpite, o melhor palpite para escanteios neste confronto reside no over oito vírgula cinco, considerando a alta frequência de cantos na Série B e a propensão ofensiva do Criciúma em casa. A consistência dos dados, com oitenta e dois por cento de acerto, oferece uma base estatística sólida para uma aposta de valor mediano e baixo risco. [OFF] [FOCO: Mais Escanteios] Encerrando o mercado de Mais Escanteios, apesar de o São Bernardo ter quarenta e quatro por cento de chances de fazer mais cantos, contra trinta e oito por cento do Criciúma, a análise tática sugere uma vantagem para o visitante. Isso se deve ao seu estilo de jogo reativo e às bolas paradas geradas em contra-ataques, mas a diferença é pequena demais para uma aposta segura. [OFF] 
"""

# Locução limpa (removendo as tags)
texto_locucao = re.sub(r'\[.*?\]', '', texto_roteiro).replace('  ', ' ').strip()

# Salvar o texto limpo em um arquivo temporário para o leitor de áudio
caminho_texto_temp = "I:\\ROTEIRO VIDEOS\\AMERICA MG\\roteiro video\\roteiro_escanteios_limpo_temp.txt"
with open(caminho_texto_temp, "w", encoding="utf-8") as f:
    f.write(texto_locucao)

# Salvar o Roteiro para a IA ler
caminho_roteiro = "I:\\ROTEIRO VIDEOS\\AMERICA MG\\roteiro video\\roteiro_teste_escanteios.txt"
with open(caminho_roteiro, "w", encoding="utf-8") as f:
    f.write(texto_roteiro)
print(f"Roteiro salvo em: {caminho_roteiro}")

# Gerar Áudio
caminho_audio = "I:\\ROTEIRO VIDEOS\\AMERICA MG\\roteiro video\\audio_teste_escanteios.mp3"
print("Gerando áudio Neural da Microsoft (Locutor: Antonio)...")

comando_tts = [
    ".\\venv\\Scripts\\edge-tts.exe",
    "--voice", "pt-BR-AntonioNeural",
    "--rate=+5%",
    "-f", caminho_texto_temp,
    "--write-media", caminho_audio
]
subprocess.run(comando_tts, check=True)
print(f"Áudio Neural salvo em: {caminho_audio}")

print("Iniciando gravação do Vídeo Modular (Escanteios)...")
subprocess.run([
    ".\\venv\\Scripts\\python.exe", "video_maker\\gerar_video.py", 
    "--url", match_url,
    "--audio", caminho_audio,
    "--roteiro", caminho_roteiro
], check=True)

print("Teste finalizado!")
