import os
import sys
import argparse
import django
import urllib.request
import time
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance

# Configure Django environment
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'core.settings')
django.setup()

from matches.models import Match

def download_image(url, save_path):
    if not os.path.exists(save_path):
        req = urllib.request.Request(
            url, 
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
                'Accept': 'image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8',
                'Referer': 'https://www.sofascore.com/',
                'Origin': 'https://www.sofascore.com'
            }
        )
        try:
            with urllib.request.urlopen(req) as response, open(save_path, 'wb') as out_file:
                out_file.write(response.read())
        except Exception as e:
            print(f"Erro ao baixar {url}: {e}")
            return False
    return True

def create_thumbnail(match_id, output_path, is_vertical=False):
    print(f"[THUMBNAIL] Iniciando geração da capa para o Match ID: {match_id}")
    try:
        match = Match.objects.get(id=match_id)
    except Match.DoesNotExist:
        print(f"[ERRO] Partida {match_id} não encontrada no banco de dados.")
        sys.exit(1)

    home_api_id = match.home_team.api_id
    away_api_id = match.away_team.api_id
    home_name = match.home_team.name.upper()
    away_name = match.away_team.name.upper()

    print(f"  - Confronto: {home_name} (ID: {home_api_id}) vs {away_name} (ID: {away_api_id})")

    # 1. Sortear um Fundo Aleatório da pasta fundos_img
    import random, glob
    fundos_dir = os.path.join(base_dir, "media", "fundos_img")
    bg_path = None
    if os.path.exists(fundos_dir):
        fundos = glob.glob(os.path.join(fundos_dir, "*.png"))
        if fundos:
            bg_path = random.choice(fundos)

    canvas_w = 1080 if is_vertical else 1920
    canvas_h = 1920 if is_vertical else 1080

    if not bg_path or not os.path.exists(bg_path):
        print(f"[AVISO] Nenhum fundo encontrado em {fundos_dir}. Usando fundo preto genérico.")
        img = Image.new('RGB', (canvas_w, canvas_h), color=(15, 20, 25))
    else:
        print(f"  - Fundo escolhido: {os.path.basename(bg_path)}")
        img = Image.open(bg_path).convert("RGBA")

    # Paths dos Escudos (Buscando pelo caminho salvo no banco de dados)
    home_logo_rel = match.home_team.logo_url.lstrip('/') if match.home_team.logo_url else ""
    away_logo_rel = match.away_team.logo_url.lstrip('/') if match.away_team.logo_url else ""
    
    home_logo_path = os.path.join(base_dir, home_logo_rel.replace('/', os.sep)) if home_logo_rel else ""
    away_logo_path = os.path.join(base_dir, away_logo_rel.replace('/', os.sep)) if away_logo_rel else ""

    if not os.path.exists(home_logo_path):
        print(f"  [AVISO] Escudo do {home_name} não encontrado no HD ({home_logo_path})")
    if not os.path.exists(away_logo_path):
        print(f"  [AVISO] Escudo do {away_name} não encontrado no HD ({away_logo_path})")
        
    # Resize bg covering the canvas (center crop)
    bg_w, bg_h = img.size
    ratio = max(canvas_w / bg_w, canvas_h / bg_h)
    new_w = int(bg_w * ratio)
    new_h = int(bg_h * ratio)
    img = img.resize((new_w, new_h), Image.Resampling.LANCZOS)
    left = (new_w - canvas_w) / 2
    top = (new_h - canvas_h) / 2
    img = img.crop((left, top, left + canvas_w, top + canvas_h))
    
    # Escurecer levemente o fundo para os times brilharem mais
    enhancer = ImageEnhance.Brightness(img)
    img = enhancer.enhance(0.7)

    # Criar camada para desenho e efeitos
    draw = ImageDraw.Draw(img)

    # 2. Add VS in the middle
    try:
        font_vs = ImageFont.truetype("impact.ttf", 200 if is_vertical else 150)
        font_title = ImageFont.truetype("impact.ttf", 150 if is_vertical else 120)
    except:
        font_vs = ImageFont.load_default()
        font_title = ImageFont.load_default()

    vs_text = "VS"
    bbox = draw.textbbox((0, 0), vs_text, font=font_vs)
    text_width = bbox[2] - bbox[0]
    text_height = bbox[3] - bbox[1]
    
    if is_vertical:
        vs_x = (canvas_w - text_width) / 2
        vs_y = (canvas_h - text_height) / 2 - 100
    else:
        vs_x = (canvas_w - text_width) / 2
        vs_y = (canvas_h - text_height) / 2 - 50

    draw.text((vs_x + 5, vs_y + 5), vs_text, font=font_vs, fill=(0, 0, 0, 150))
    outline_color = (0, 0, 0)
    for adj in range(-3, 4):
        for adj2 in range(-3, 4):
            draw.text((vs_x + adj, vs_y + adj2), vs_text, font=font_vs, fill=outline_color)
    draw.text((vs_x, vs_y), vs_text, font=font_vs, fill=(255, 255, 255))

    # 3. Add Logos
    logo_size = (550, 550) if is_vertical else (450, 450)
    
    if os.path.exists(home_logo_path):
        home_img = Image.open(home_logo_path).convert("RGBA")
        home_img = home_img.resize(logo_size, Image.Resampling.LANCZOS)
        
        if is_vertical:
            x_home = (canvas_w - logo_size[0]) // 2
            y_home = vs_y - logo_size[1] - 50
        else:
            x_home = 200
            y_home = (canvas_h - logo_size[1]) // 2 - 50
            
        img.alpha_composite(home_img, (int(x_home), int(y_home)))
    
    if os.path.exists(away_logo_path):
        away_img = Image.open(away_logo_path).convert("RGBA")
        away_img = away_img.resize(logo_size, Image.Resampling.LANCZOS)
        
        if is_vertical:
            x_away = (canvas_w - logo_size[0]) // 2
            y_away = vs_y + text_height + 50
        else:
            x_away = canvas_w - 200 - logo_size[0]
            y_away = (canvas_h - logo_size[1]) // 2 - 50
            
        img.alpha_composite(away_img, (int(x_away), int(y_away)))

    # 4. Título Principal (Embaixo)
    title_text = f"ANÁLISE DE HOJE\n{home_name} X {away_name}" if is_vertical else f"ANÁLISE DE HOJE: {home_name} X {away_name}"
    
    t_font = font_title
    t_size = 150 if is_vertical else 120
    
    # Check max width
    max_w = canvas_w - 100
    while True:
        # Measure multiline text width
        lines = title_text.split('\n')
        max_line_w = max([draw.textbbox((0, 0), line, font=t_font)[2] for line in lines])
        if max_line_w < max_w or t_size < 50:
            break
        t_size -= 5
        try:
            t_font = ImageFont.truetype("impact.ttf", t_size)
        except:
            break

    # Measure final bounding box for multiple lines
    total_h = 0
    max_line_w = 0
    line_metrics = []
    lines = title_text.split('\n')
    for line in lines:
        bbox_l = draw.textbbox((0, 0), line, font=t_font)
        lw = bbox_l[2] - bbox_l[0]
        lh = bbox_l[3] - bbox_l[1]
        line_metrics.append((lw, lh))
        max_line_w = max(max_line_w, lw)
        total_h += lh + 10 # 10px spacing

    title_x = (canvas_w - max_line_w) / 2
    title_y = canvas_h - total_h - (200 if is_vertical else 100)
    
    # Caixa amarela de fundo pro título
    box_padding = 30 if is_vertical else 20
    draw.rectangle([title_x - box_padding, title_y - box_padding, title_x + max_line_w + box_padding, title_y + total_h + box_padding], fill=(249, 115, 22)) 
    
    current_y = title_y
    for i, line in enumerate(lines):
        lw, lh = line_metrics[i]
        lx = (canvas_w - lw) / 2
        draw.text((lx, current_y), line, font=t_font, fill=(0, 0, 0))
        current_y += lh + 10

    # Convert to RGB to save
    final_img = img.convert("RGB")
    final_img.save(output_path, "PNG")
    print(f"  [SUCESSO] Miniatura gerada em: {output_path}")

def main():
    parser = argparse.ArgumentParser(description="Statsfut Thumbnail Generator")
    parser.add_argument("--url", type=str, help="URL da partida")
    parser.add_argument("--output", type=str, help="Caminho onde salvar o PNG")
    parser.add_argument("--vertical", action="store_true", help="Gera capa vertical (9:16) para TikTok/Shorts")
    args = parser.parse_args()

    if not args.url or not args.output:
        print("[ERRO] É necessário passar --url e --output")
        sys.exit(1)

    try:
        parts = args.url.strip('/').split('/')
        match_id = int(parts[-1])
    except ValueError:
        print(f"[ERRO] Não foi possível extrair o ID da partida da URL: {args.url}")
        sys.exit(1)

    create_thumbnail(match_id, args.output, is_vertical=args.vertical)

if __name__ == "__main__":
    main()
