import os
import sys
import json
import time
import glob
import re
import threading
import subprocess
import customtkinter as ctk

# Configurações do CustomTkinter (Visual Premium)
ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class VideoStudioApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("StatsFut - Fábrica de Vídeos (Desktop)")
        self.geometry("1200x850")
        self.resizable(False, False)
        
        self.base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        self.fila_dir = os.path.join(self.base_dir, 'media', 'videos', 'fila')
        os.makedirs(self.fila_dir, exist_ok=True)

        # Layout Principal
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)

        main_frame = ctk.CTkFrame(self, fg_color="transparent")
        main_frame.grid(row=0, column=0, padx=20, pady=20, sticky="nsew")
        main_frame.grid_columnconfigure(0, weight=1)
        main_frame.grid_rowconfigure(2, weight=1)

        # Título
        title_label = ctk.CTkLabel(main_frame, text="FÁBRICA DE VÍDEOS", font=ctk.CTkFont(family="Inter", size=32, weight="bold"), text_color="#f97316")
        title_label.grid(row=0, column=0, pady=(0, 5))
        
        subtitle = ctk.CTkLabel(main_frame, text="Gere vídeos automatizados cinematográficos rodando no Windows.", text_color="#94a3b8")
        subtitle.grid(row=1, column=0, pady=(0, 10))

        # ==========================================
        # ABAS (TabView)
        # ==========================================
        self.tabview = ctk.CTkTabview(main_frame, fg_color="#0f172a", segmented_button_selected_color="#f97316", segmented_button_selected_hover_color="#ea580c", segmented_button_unselected_color="#1e293b", segmented_button_unselected_hover_color="#334155", border_width=1, border_color="#f97316", corner_radius=12)
        self.tabview.grid(row=2, column=0, sticky="nsew")
        
        tab_individual = self.tabview.add("🎬 Individual")
        tab_fila = self.tabview.add("📦 Fila de Produção")
        
        # ==========================================
        # ABA 1: INDIVIDUAL (código original)
        # ==========================================
        tab_individual.grid_columnconfigure((0, 1), weight=1)
        tab_individual.grid_rowconfigure(0, weight=1)

        # --- PAINEL DE CONFIGURAÇÃO (Esquerda) ---
        config_frame = ctk.CTkFrame(tab_individual, fg_color="#0f172a", border_width=0, corner_radius=12)
        config_frame.grid(row=0, column=0, padx=(0, 10), sticky="nsew")
        config_frame.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(config_frame, text="⚙️ Configuração", font=ctk.CTkFont(size=16, weight="bold"), text_color="white").pack(anchor="w", padx=20, pady=(20, 10))

        # URL
        ctk.CTkLabel(config_frame, text="URL da Partida no Statsfut", text_color="#cbd5e1").pack(anchor="w", padx=20)
        self.entry_url = ctk.CTkEntry(config_frame, placeholder_text="https://statsfut.com/pt-br/match/123/...", height=35, fg_color="#1e293b", border_color="#475569")
        self.entry_url.pack(fill="x", padx=20, pady=(0, 15))

        # Áudio
        ctk.CTkLabel(config_frame, text="Caminho do Áudio MP3 (Opcional)", text_color="#cbd5e1").pack(anchor="w", padx=20)
        self.entry_audio = ctk.CTkEntry(config_frame, placeholder_text="Deixe em branco para usar a voz automática do Antonio", height=35, fg_color="#1e293b", border_color="#475569")
        self.entry_audio.pack(fill="x", padx=20, pady=(0, 15))

        # Roteiro
        ctk.CTkLabel(config_frame, text="Roteiro (Cole o texto gerado pela IA aqui)", text_color="#cbd5e1").pack(anchor="w", padx=20)
        self.textbox_roteiro = ctk.CTkTextbox(config_frame, height=200, fg_color="#1e293b", border_color="#475569", border_width=1)
        self.textbox_roteiro.pack(fill="x", padx=20, pady=(0, 15))

        # Botões
        btn_frame = ctk.CTkFrame(config_frame, fg_color="transparent")
        btn_frame.pack(fill="x", padx=20, pady=(10, 20))
        btn_frame.grid_columnconfigure((0, 1), weight=1)

        self.btn_youtube = ctk.CTkButton(btn_frame, text="🎬 YouTube (Longo)", fg_color="#2563eb", hover_color="#1d4ed8", font=ctk.CTkFont(weight="bold"), height=40, command=lambda: self.start_generation("long"))
        self.btn_youtube.grid(row=0, column=0, padx=(0, 5), sticky="ew")

        self.btn_tiktok = ctk.CTkButton(btn_frame, text="📱 TikTok (Curto)", fg_color="#ea580c", hover_color="#c2410c", font=ctk.CTkFont(weight="bold"), height=40, command=lambda: self.start_generation("short"))
        self.btn_tiktok.grid(row=0, column=1, padx=(5, 0), sticky="ew")

        # --- PAINEL DE TERMINAL (Direita) ---
        term_frame = ctk.CTkFrame(tab_individual, fg_color="#0f172a", border_width=0, corner_radius=12)
        term_frame.grid(row=0, column=1, padx=(10, 0), sticky="nsew")
        term_frame.grid_rowconfigure(1, weight=1)
        term_frame.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(term_frame, text="💻 Terminal Ao Vivo", font=ctk.CTkFont(size=16, weight="bold"), text_color="white").grid(row=0, column=0, sticky="w", padx=20, pady=(20, 10))

        self.textbox_log = ctk.CTkTextbox(term_frame, fg_color="#000000", text_color="#4ade80", font=ctk.CTkFont(family="Courier", size=12))
        self.textbox_log.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="nsew")
        self.textbox_log.insert("0.0", "> Aguardando início do processamento...\n")
        self.textbox_log.configure(state="disabled")
        
        self.process = None

        # ==========================================
        # ABA 2: FILA DE PRODUÇÃO
        # ==========================================
        tab_fila.grid_columnconfigure(0, weight=1)
        tab_fila.grid_columnconfigure(1, weight=1)
        tab_fila.grid_rowconfigure(0, weight=1)
        
        # --- COLUNA ESQUERDA: Lista de Jobs ---
        fila_left = ctk.CTkFrame(tab_fila, fg_color="#0f172a", border_width=0, corner_radius=12)
        fila_left.grid(row=0, column=0, padx=(0, 10), sticky="nsew")
        fila_left.grid_columnconfigure(0, weight=1)
        fila_left.grid_rowconfigure(2, weight=1)
        
        # Header
        header_frame = ctk.CTkFrame(fila_left, fg_color="transparent")
        header_frame.grid(row=0, column=0, padx=20, pady=(20, 5), sticky="ew")
        header_frame.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(header_frame, text="📦 Fila de Produção", font=ctk.CTkFont(size=16, weight="bold"), text_color="white").grid(row=0, column=0, sticky="w")
        
        # Info
        info_text = (
            f"Coloque pastas dentro de:\n"
            f"media/videos/fila/\n\n"
            f"Cada pasta deve conter:\n"
            f"• url.txt  (link do jogo)\n"
            f"• roteiro.txt  (texto da máquina)\n"
            f"• audio.mp3  (áudio da locução, opcional)"
        )
        info_label = ctk.CTkLabel(fila_left, text=info_text, text_color="#94a3b8", font=ctk.CTkFont(size=12), justify="left", anchor="w")
        info_label.grid(row=1, column=0, padx=20, pady=(0, 10), sticky="w")
        
        # Scrollable Frame para os jobs
        self.jobs_scroll = ctk.CTkScrollableFrame(fila_left, fg_color="#111827", corner_radius=8, border_width=1, border_color="#334155")
        self.jobs_scroll.grid(row=2, column=0, padx=20, pady=(0, 10), sticky="nsew")
        self.jobs_scroll.grid_columnconfigure(0, weight=1)
        
        self.job_widgets = []  # Lista de widgets dos jobs
        self.job_data = []  # Lista de dados dos jobs
        
        # Placeholder vazio
        self.empty_label = ctk.CTkLabel(self.jobs_scroll, text="Nenhum jogo na fila.\nClique em 'Escanear Pasta' para começar.", text_color="#475569", font=ctk.CTkFont(size=13))
        self.empty_label.grid(row=0, column=0, pady=40)
        
        # Botões da fila
        fila_btn_frame = ctk.CTkFrame(fila_left, fg_color="transparent")
        fila_btn_frame.grid(row=3, column=0, padx=20, pady=(5, 20), sticky="ew")
        fila_btn_frame.grid_columnconfigure((0, 1), weight=1)

        self.btn_scan = ctk.CTkButton(fila_btn_frame, text="🔍 Escanear Pasta", fg_color="#6366f1", hover_color="#4f46e5", font=ctk.CTkFont(weight="bold"), height=40, command=self.scan_fila)
        self.btn_scan.grid(row=0, column=0, padx=(0, 5), sticky="ew")
        
        self.btn_abrir_pasta = ctk.CTkButton(fila_btn_frame, text="📂 Abrir Pasta", fg_color="#475569", hover_color="#374151", font=ctk.CTkFont(weight="bold"), height=40, command=self.abrir_pasta_fila)
        self.btn_abrir_pasta.grid(row=0, column=1, padx=(5, 0), sticky="ew")

        # Formato + Botão Produzir
        fila_produce_frame = ctk.CTkFrame(fila_left, fg_color="transparent")
        fila_produce_frame.grid(row=4, column=0, padx=20, pady=(0, 20), sticky="ew")
        fila_produce_frame.grid_columnconfigure(0, weight=1)
        
        # Seletor de formato
        format_frame = ctk.CTkFrame(fila_produce_frame, fg_color="transparent")
        format_frame.grid(row=0, column=0, sticky="ew", pady=(0, 8))
        format_frame.grid_columnconfigure(1, weight=1)
        
        ctk.CTkLabel(format_frame, text="Formato:", text_color="#cbd5e1", font=ctk.CTkFont(size=13)).grid(row=0, column=0, padx=(0, 10))
        self.fila_format = ctk.CTkSegmentedButton(format_frame, values=["YouTube (Longo)", "TikTok (Curto)"], font=ctk.CTkFont(size=12), selected_color="#f97316", selected_hover_color="#ea580c", unselected_color="#1e293b", unselected_hover_color="#334155")
        self.fila_format.set("YouTube (Longo)")
        self.fila_format.grid(row=0, column=1, sticky="ew")

        self.btn_produzir = ctk.CTkButton(fila_produce_frame, text="🚀 PRODUZIR TODA A FILA", fg_color="#16a34a", hover_color="#15803d", font=ctk.CTkFont(size=15, weight="bold"), height=50, command=self.start_fila)
        self.btn_produzir.grid(row=1, column=0, sticky="ew")

        # --- COLUNA DIREITA: Terminal da Fila ---
        fila_right = ctk.CTkFrame(tab_fila, fg_color="#0f172a", border_width=0, corner_radius=12)
        fila_right.grid(row=0, column=1, padx=(10, 0), sticky="nsew")
        fila_right.grid_rowconfigure(1, weight=1)
        fila_right.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(fila_right, text="💻 Terminal da Fila", font=ctk.CTkFont(size=16, weight="bold"), text_color="white").grid(row=0, column=0, sticky="w", padx=20, pady=(20, 10))

        self.textbox_fila_log = ctk.CTkTextbox(fila_right, fg_color="#000000", text_color="#4ade80", font=ctk.CTkFont(family="Courier", size=12))
        self.textbox_fila_log.grid(row=1, column=0, padx=20, pady=(0, 20), sticky="nsew")
        self.textbox_fila_log.insert("0.0", "> Fila vazia. Escaneie a pasta para começar.\n")
        self.textbox_fila_log.configure(state="disabled")
        
        self.fila_running = False

    # ==========================================
    # MÉTODOS: ABA INDIVIDUAL (original)
    # ==========================================
    def log(self, message):
        self.textbox_log.configure(state="normal")
        self.textbox_log.insert("end", message + "\n")
        self.textbox_log.see("end")
        self.textbox_log.configure(state="disabled")

    def start_generation(self, format_type):
        if self.process and self.process.poll() is None:
            self.log("[ERRO] Um vídeo já está sendo gerado! Aguarde.")
            return

        url = self.entry_url.get().strip()
        audio = self.entry_audio.get().strip()
        roteiro = self.textbox_roteiro.get("0.0", "end").strip()

        if not url or not roteiro:
            self.log("[ERRO] Preencha URL e Roteiro no mínimo!")
            return

        self.textbox_log.configure(state="normal")
        self.textbox_log.delete("0.0", "end")
        self.textbox_log.configure(state="disabled")
        self.log(f"> Disparando robô de gravação para o formato {'TikTok (9:16)' if format_type == 'short' else 'YouTube (16:9)'}...")

        # Roda em thread para não travar a UI
        thread = threading.Thread(target=self.run_process, args=(url, audio, roteiro, format_type))
        thread.start()

    def run_process(self, match_url, audio_path, roteiro_text, format_type):
        base_dir = self.base_dir
        videos_dir = os.path.join(base_dir, 'media', 'videos', 'temp')
        os.makedirs(videos_dir, exist_ok=True)

        # 1. Gerar áudio caso vazio
        if not audio_path:
            self.log("> Gerando áudio automático (Antonio)...")
            try:
                texto_limpo = roteiro_text.split("👇👇👇 TEXTO DA MÁQUINA")[0].replace("👇👇👇 TEXTO DO ÁUDIO (COPIE TUDO AQUI ABAIXO E COLE NO ELEVENLABS) 👇👇👇", "")
                # Remove todas as tags da máquina (ABA, FOCO e OFF) para o robô não ler em voz alta
                texto_limpo = re.sub(r'\[ABA:.*?\]', '', texto_limpo, flags=re.IGNORECASE)
                texto_limpo = re.sub(r'\[FOCO:.*?\]', '', texto_limpo, flags=re.IGNORECASE)
                texto_limpo = re.sub(r'\[OFF\]', '', texto_limpo, flags=re.IGNORECASE)
                texto_limpo = texto_limpo.strip()
                
                texto_limpo_path = os.path.join(videos_dir, 'roteiro_limpo_temp.txt')
                with open(texto_limpo_path, 'w', encoding='utf-8') as f:
                    f.write(texto_limpo)
                    
                audio_path = os.path.join(videos_dir, f'auto_audio_{int(time.time())}.mp3')
                rate = "+20%" if format_type == 'short' else "+0%"
                
                # Executa o edge-tts via caminho absoluto do venv escondendo a janela preta
                edge_tts_exe = os.path.join(base_dir, "venv", "Scripts", "edge-tts.exe")
                subprocess.run(
                    f'"{edge_tts_exe}" --voice pt-BR-AntonioNeural --rate {rate} -f "{texto_limpo_path}" --write-media "{audio_path}"',
                    shell=True, check=True,
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)
                )
                self.log("> Áudio gerado com sucesso.")
            except Exception as e:
                self.log(f"[ERRO ÁUDIO] {str(e)}")
                return

        # 2. Salvar roteiro
        roteiro_path = os.path.join(videos_dir, 'roteiro_temp.txt')
        with open(roteiro_path, 'w', encoding='utf-8') as f:
            f.write(roteiro_text)

        # 3. Executar o robô de vídeo
        script_name = "gerar_video.py" if format_type == 'long' else "gerar_video_curto.py"
        script_path = os.path.join(base_dir, "video_maker", script_name)
        
        venv_python = os.path.join(base_dir, "venv", "Scripts", "python.exe")
        if not os.path.exists(venv_python):
            venv_python = "python"
            
        cmd = [
            venv_python, "-u", script_path,
            "--url", match_url,
            "--audio", audio_path,
            "--roteiro", roteiro_path
        ]

        self.log(f"> Executando: {script_name}...")
        
        # Altera os botões para mostrar que está rodando
        self.btn_youtube.configure(state="disabled", text="⏳ Gravando...")
        self.btn_tiktok.configure(state="disabled", text="⏳ Gravando...")
        
        try:
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding='utf-8',
                errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)
            )
            
            # Ler o terminal linha por linha em tempo real
            for line in iter(self.process.stdout.readline, ''):
                if line:
                    self.log(line.strip())
            
            self.process.stdout.close()
            self.process.wait()
            
            if self.process.returncode == 0:
                self.log("\n✅ [SUCESSO] Processo Finalizado!")
            else:
                self.log(f"\n❌ [ERRO] O processo retornou código {self.process.returncode}")
                
        except Exception as e:
            self.log(f"[ERRO GERAL] {str(e)}")
        finally:
            # Restaura os botões
            self.btn_youtube.configure(state="normal", text="🎬 YouTube (Longo)")
            self.btn_tiktok.configure(state="normal", text="📱 TikTok (Curto)")

    # ==========================================
    # MÉTODOS: ABA FILA DE PRODUÇÃO
    # ==========================================
    def fila_log(self, message):
        self.textbox_fila_log.configure(state="normal")
        self.textbox_fila_log.insert("end", message + "\n")
        self.textbox_fila_log.see("end")
        self.textbox_fila_log.configure(state="disabled")
    
    def abrir_pasta_fila(self):
        """Abre a pasta da fila no Windows Explorer"""
        os.makedirs(self.fila_dir, exist_ok=True)
        os.startfile(self.fila_dir)
    
    def scan_fila(self):
        """Escaneia a pasta fila/ e lista os jobs encontrados"""
        # Limpar widgets antigos
        for w in self.job_widgets:
            w.destroy()
        self.job_widgets.clear()
        self.job_data.clear()
        
        if hasattr(self, 'empty_label') and self.empty_label.winfo_exists():
            self.empty_label.destroy()
        
        # Limpar terminal
        self.textbox_fila_log.configure(state="normal")
        self.textbox_fila_log.delete("0.0", "end")
        self.textbox_fila_log.configure(state="disabled")
        
        self.fila_log(f"> Escaneando pasta: {self.fila_dir}")
        
        if not os.path.isdir(self.fila_dir):
            self.fila_log("[AVISO] Pasta fila/ não encontrada. Criando...")
            os.makedirs(self.fila_dir, exist_ok=True)
            return
        
        # Listar subpastas
        subfolders = sorted([
            d for d in os.listdir(self.fila_dir)
            if os.path.isdir(os.path.join(self.fila_dir, d))
        ])
        
        if not subfolders:
            self.fila_log("[AVISO] Nenhuma pasta encontrada dentro de fila/.")
            self.fila_log(f"Crie pastas com url.txt + roteiro.txt + audio.mp3 dentro de:")
            self.fila_log(f"  {self.fila_dir}")
            self.empty_label = ctk.CTkLabel(self.jobs_scroll, text="Nenhum jogo na fila.\nCrie pastas dentro de media/videos/fila/", text_color="#475569", font=ctk.CTkFont(size=13))
            self.empty_label.grid(row=0, column=0, pady=40)
            return
        
        found = 0
        for idx, folder_name in enumerate(subfolders):
            folder_path = os.path.join(self.fila_dir, folder_name)
            
            # Procurar arquivos dentro da pasta
            url_file = os.path.join(folder_path, 'url.txt')
            roteiro_file = None
            audio_file = None
            
            # Procura roteiro (aceita variações de nome)
            for f in os.listdir(folder_path):
                fl = f.lower()
                if fl.endswith('.txt') and fl != 'url.txt':
                    roteiro_file = os.path.join(folder_path, f)
                if fl.endswith('.mp3') or fl.endswith('.wav'):
                    audio_file = os.path.join(folder_path, f)
            
            # Verificar URL
            url_text = ""
            if os.path.isfile(url_file):
                with open(url_file, 'r', encoding='utf-8') as f:
                    url_text = f.read().strip()
            
            has_url = bool(url_text)
            has_roteiro = roteiro_file is not None
            has_audio = audio_file is not None
            
            # Determinar status
            if has_url and has_roteiro:
                status = "✅ Pronto"
                status_color = "#4ade80"
            elif has_url and not has_roteiro:
                status = "⚠️ Sem Roteiro"
                status_color = "#fbbf24"
            elif not has_url and has_roteiro:
                status = "⚠️ Sem URL"
                status_color = "#fbbf24"
            else:
                status = "❌ Incompleto"
                status_color = "#ef4444"
            
            audio_status = "🔊 Áudio OK" if has_audio else "🤖 Voz Auto"
            
            # Criar widget do job
            job_frame = ctk.CTkFrame(self.jobs_scroll, fg_color="#1e293b", corner_radius=8, border_width=1, border_color="#334155", height=60)
            job_frame.grid(row=idx, column=0, padx=5, pady=3, sticky="ew")
            job_frame.grid_columnconfigure(1, weight=1)
            
            # Número
            num_label = ctk.CTkLabel(job_frame, text=f"{idx+1}", font=ctk.CTkFont(size=18, weight="bold"), text_color="#f97316", width=35)
            num_label.grid(row=0, column=0, rowspan=2, padx=(12, 5), pady=8)
            
            # Nome do jogo
            name_label = ctk.CTkLabel(job_frame, text=folder_name, font=ctk.CTkFont(size=13, weight="bold"), text_color="white", anchor="w")
            name_label.grid(row=0, column=1, padx=5, pady=(8, 0), sticky="w")
            
            # Status
            detail_text = f"{status}  •  {audio_status}"
            detail_label = ctk.CTkLabel(job_frame, text=detail_text, font=ctk.CTkFont(size=11), text_color=status_color, anchor="w")
            detail_label.grid(row=1, column=1, padx=5, pady=(0, 8), sticky="w")
            
            self.job_widgets.append(job_frame)
            self.job_data.append({
                'name': folder_name,
                'folder': folder_path,
                'url': url_text,
                'roteiro': roteiro_file,
                'audio': audio_file,
                'ready': has_url and has_roteiro,
                'widget': job_frame,
                'status_label': detail_label
            })
            
            if has_url and has_roteiro:
                found += 1
                self.fila_log(f"  ✅ {folder_name} - {audio_status}")
            else:
                self.fila_log(f"  ⚠️ {folder_name} - {status}")
        
        self.fila_log(f"\n> {found} jogo(s) prontos para produzir de {len(subfolders)} pasta(s) encontrada(s).")
        if found < len(subfolders):
            self.fila_log(f"  ({len(subfolders) - found} pasta(s) estão incompletas e serão puladas.)")
    
    def start_fila(self):
        """Inicia a produção em lote de todos os jobs prontos"""
        if self.fila_running:
            self.fila_log("[ERRO] A fila já está sendo processada! Aguarde.")
            return
        
        ready_jobs = [j for j in self.job_data if j['ready']]
        
        if not ready_jobs:
            self.fila_log("[ERRO] Nenhum jogo pronto na fila! Escaneie a pasta primeiro.")
            return
        
        self.fila_running = True
        self.btn_produzir.configure(state="disabled", text="⏳ Produzindo...")
        self.btn_scan.configure(state="disabled")
        
        thread = threading.Thread(target=self.run_fila, args=(ready_jobs,))
        thread.start()
    
    def run_fila(self, jobs):
        """Processa todos os jobs da fila sequencialmente"""
        format_choice = self.fila_format.get()
        format_type = "short" if "TikTok" in format_choice else "long"
        
        total = len(jobs)
        sucesso = 0
        erros = 0
        
        self.textbox_fila_log.configure(state="normal")
        self.textbox_fila_log.delete("0.0", "end")
        self.textbox_fila_log.configure(state="disabled")
        
        self.fila_log(f"{'='*50}")
        self.fila_log(f"🚀 INICIANDO PRODUÇÃO EM LOTE")
        self.fila_log(f"   Formato: {format_choice}")
        self.fila_log(f"   Total de jobs: {total}")
        self.fila_log(f"{'='*50}\n")
        
        for idx, job in enumerate(jobs):
            job_num = idx + 1
            self.fila_log(f"{'─'*50}")
            self.fila_log(f"▶ [{job_num}/{total}] {job['name']}")
            self.fila_log(f"{'─'*50}")
            
            # Atualizar visual do widget
            try:
                job['status_label'].configure(text=f"⏳ Processando... ({job_num}/{total})", text_color="#60a5fa")
                job['widget'].configure(border_color="#60a5fa")
            except:
                pass
            
            try:
                # Ler roteiro
                with open(job['roteiro'], 'r', encoding='utf-8') as f:
                    roteiro_text = f.read().strip()
                
                match_url = job['url']
                audio_path = job['audio'] if job['audio'] else ""
                
                # Gerar áudio se não tiver
                if not audio_path:
                    self.fila_log("> Gerando áudio automático (Antonio)...")
                    try:
                        texto_limpo = roteiro_text.split("👇👇👇 TEXTO DA MÁQUINA")[0].replace("👇👇👇 TEXTO DO ÁUDIO (COPIE TUDO AQUI ABAIXO E COLE NO ELEVENLABS) 👇👇👇", "")
                        texto_limpo = re.sub(r'\[ABA:.*?\]', '', texto_limpo, flags=re.IGNORECASE)
                        texto_limpo = re.sub(r'\[FOCO:.*?\]', '', texto_limpo, flags=re.IGNORECASE)
                        texto_limpo = re.sub(r'\[OFF\]', '', texto_limpo, flags=re.IGNORECASE)
                        texto_limpo = texto_limpo.strip()
                        
                        temp_dir = os.path.join(self.base_dir, 'media', 'videos', 'temp')
                        os.makedirs(temp_dir, exist_ok=True)
                        texto_limpo_path = os.path.join(temp_dir, 'roteiro_limpo_temp.txt')
                        with open(texto_limpo_path, 'w', encoding='utf-8') as f:
                            f.write(texto_limpo)
                        
                        audio_path = os.path.join(temp_dir, f'auto_audio_{int(time.time())}.mp3')
                        rate = "+20%" if format_type == 'short' else "+0%"
                        edge_tts_exe = os.path.join(self.base_dir, "venv", "Scripts", "edge-tts.exe")
                        subprocess.run(
                            f'"{edge_tts_exe}" --voice pt-BR-AntonioNeural --rate {rate} -f "{texto_limpo_path}" --write-media "{audio_path}"',
                            shell=True, check=True,
                            creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)
                        )
                        self.fila_log("> Áudio gerado com sucesso.")
                    except Exception as e:
                        self.fila_log(f"[ERRO ÁUDIO] {str(e)}")
                        erros += 1
                        try:
                            job['status_label'].configure(text="❌ Erro no Áudio", text_color="#ef4444")
                            job['widget'].configure(border_color="#ef4444")
                        except:
                            pass
                        continue
                
                # Salvar roteiro em arquivo temp
                temp_dir = os.path.join(self.base_dir, 'media', 'videos', 'temp')
                os.makedirs(temp_dir, exist_ok=True)
                roteiro_path = os.path.join(temp_dir, 'roteiro_temp.txt')
                with open(roteiro_path, 'w', encoding='utf-8') as f:
                    f.write(roteiro_text)
                
                # Executar o robô
                script_name = "gerar_video.py" if format_type == 'long' else "gerar_video_curto.py"
                script_path = os.path.join(self.base_dir, "video_maker", script_name)
                venv_python = os.path.join(self.base_dir, "venv", "Scripts", "python.exe")
                if not os.path.exists(venv_python):
                    venv_python = "python"
                
                cmd = [
                    venv_python, "-u", script_path,
                    "--url", match_url,
                    "--audio", audio_path,
                    "--roteiro", roteiro_path
                ]
                
                self.fila_log(f"> Executando: {script_name}...")
                
                proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)
                )
                
                for line in iter(proc.stdout.readline, ''):
                    if line:
                        self.fila_log(line.strip())
                
                proc.stdout.close()
                proc.wait()
                
                if proc.returncode == 0:
                    sucesso += 1
                    self.fila_log(f"\n✅ [{job_num}/{total}] {job['name']} - CONCLUÍDO!\n")
                    try:
                        job['status_label'].configure(text="✅ Concluído!", text_color="#4ade80")
                        job['widget'].configure(border_color="#4ade80")
                    except:
                        pass
                else:
                    erros += 1
                    self.fila_log(f"\n❌ [{job_num}/{total}] {job['name']} - ERRO (código {proc.returncode})\n")
                    try:
                        job['status_label'].configure(text=f"❌ Erro (código {proc.returncode})", text_color="#ef4444")
                        job['widget'].configure(border_color="#ef4444")
                    except:
                        pass
                        
            except Exception as e:
                erros += 1
                self.fila_log(f"\n❌ [{job_num}/{total}] {job['name']} - EXCEÇÃO: {str(e)}\n")
                try:
                    job['status_label'].configure(text=f"❌ Exceção", text_color="#ef4444")
                    job['widget'].configure(border_color="#ef4444")
                except:
                    pass
        
        # Resumo Final
        self.fila_log(f"\n{'='*50}")
        self.fila_log(f"🏁 PRODUÇÃO FINALIZADA!")
        self.fila_log(f"   ✅ Sucesso: {sucesso}/{total}")
        if erros > 0:
            self.fila_log(f"   ❌ Erros: {erros}/{total}")
        self.fila_log(f"{'='*50}")
        
        # Restaurar botões
        self.fila_running = False
        self.btn_produzir.configure(state="normal", text="🚀 PRODUZIR TODA A FILA")
        self.btn_scan.configure(state="normal")


if __name__ == "__main__":
    app = VideoStudioApp()
    app.mainloop()
