import os
import requests
import argparse
import time
from typing import Dict, Any

# ==============================================================================
# SCRIPT 100% INDEPENDENTE - SKILL GERADOR DE ROTEIRO
# Finge ser o navegador do usuário e pede para a Inteligência Artificial
# do site StatsFut gerar o roteiro da partida.
# ==============================================================================

def gerar_roteiro(match_id: int, formato: str, abas: str, base_url: str = "http://127.0.0.1:8000") -> Dict[str, Any]:
    """
    Faz uma requisição GET para a rota de geração de roteiro do StatsFut.
    Nota: A IA pode demorar até 30-40 segundos para responder, então o timeout é longo.
    """
    # A rota oficial do site que faz a mágica acontecer
    url = f"{base_url}/pt-br/match/{match_id}/video-script/"
    params = {
        'format': formato,
        'aba': abas,
        'secret': os.getenv('STATS_FUT_SECRET', 'sk_live_3f9b2d8c1e7a4f5c9e2d1b8a7c3f6e5d')
    }
    
    print(f"[OpenClaw Skill] Solicitando Roteiro (Formato: {formato}, Abas: {abas}) para o jogo {match_id}...")
    
    try:
        # Timeout longo pois o backend da StatsFut precisa falar com a IA (OpenAI/Anthropic)
        start = time.time()
        response = requests.get(url, params=params, timeout=120)
        duracao = round(time.time() - start, 1)
        
        # Algumas rotas podem pedir autenticação ou bloquear bots, mas como
        # vamos rodar em localhost no servidor, geralmente passa direto.
        if response.status_code != 200:
            print(f"[OpenClaw Skill] Erro na requisição (HTTP {response.status_code}): {response.text[:200]}")
            return {"status": "error", "message": f"Erro HTTP {response.status_code}"}
            
        data = response.json()
        
        if data.get('status') == 'error':
            print(f"[OpenClaw Skill] Erro retornado pela API: {data.get('message')}")
            return {"status": "error", "message": data.get('message')}
            
        # O backend da StatsFut costuma retornar 'roteiro' ou 'script'
        # Precisamos nos adaptar à chave exata que ele devolve
        script_texto = data.get('script') or data.get('roteiro_text') or data.get('data')
        
        if not script_texto:
            print("[OpenClaw Skill] Sucesso HTTP, mas nenhum texto de roteiro foi encontrado no JSON.")
            print("Resposta bruta:", data)
            return {"status": "error", "message": "Roteiro não encontrado no JSON de resposta."}
            
        print(f"[OpenClaw Skill] Roteiro gerado com sucesso em {duracao}s!")
        return {"status": "success", "roteiro_text": script_texto}
        
    except requests.exceptions.Timeout:
        print("[OpenClaw Skill] Erro: A Inteligência Artificial do site demorou muito para responder (Timeout).")
        return {"status": "error", "message": "Timeout aguardando a IA."}
    except Exception as e:
        print(f"[OpenClaw Skill] Falha de conexão: {str(e)}")
        return {"status": "error", "message": str(e)}

def salvar_roteiro_local(texto: str, destino: str = "roteiro.txt"):
    """
    Salva o texto gerado em um arquivo .txt para o gerar_video.py usar depois.
    """
    try:
        with open(destino, 'w', encoding='utf-8') as f:
            f.write(texto)
        print(f"[OpenClaw Skill] Roteiro salvo com sucesso no arquivo: {destino}")
        return True
    except Exception as e:
        print(f"[OpenClaw Skill] Erro ao salvar o arquivo txt: {str(e)}")
        return False

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Skill do OpenClaw para gerar Roteiro de IA")
    parser.add_argument("--match_id", type=int, required=True, help="ID da partida no banco de dados")
    parser.add_argument("--formato", type=str, choices=['short', 'long'], default='short', help="Formato do roteiro (short para Shorts, long para YouTube)")
    parser.add_argument("--abas", type=str, default='gols', help="Abas a serem analisadas (ex: gols,escanteios,cartoes)")
    parser.add_argument("--base_url", type=str, default="http://127.0.0.1:8000", help="URL do site StatsFut")
    parser.add_argument("--saida", type=str, default="roteiro.txt", help="Caminho onde o roteiro.txt será salvo")
    
    args = parser.parse_args()
    
    resultado = gerar_roteiro(args.match_id, args.formato, args.abas, args.base_url)
    
    if resultado['status'] == 'success':
        salvar_roteiro_local(resultado['roteiro_text'], args.saida)
        print(f"SUCESSO_ARQUIVO: {args.saida}")
