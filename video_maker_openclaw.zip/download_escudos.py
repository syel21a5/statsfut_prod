import os
import sys
import django
import time
from curl_cffi import requests

# Configura o ambiente Django
base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(base_dir)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "core.settings")
django.setup()

from matches.models import Team
from django.utils.text import slugify

def download_escudos():
    print("Iniciando o download de Escudos para STATIC/TEAMS (SofaScore + API-Football)...")
    session = requests.Session(impersonate="chrome110")
    session.headers.update({
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Accept": "image/webp,image/apng,image/*,*/*;q=0.8",
        "Origin": "https://www.sofascore.com",
        "Referer": "https://www.sofascore.com/"
    })

    # Pega todos os times que possuem um ID válido (numérico ou de sofascore)
    teams = Team.objects.exclude(api_id__isnull=True).exclude(api_id="")
    
    # Pasta raiz para os escudos: static/teams/ (Para sincronizar com o Servidor!)
    escudos_dir = os.path.join(base_dir, 'static', 'teams')
    
    downloaded = 0
    skipped = 0
    errors = 0

    print(f"Encontrados {teams.count()} times no banco de dados para analisar.")

    for team in teams:
        country_slug = slugify(team.league.country)
        league_slug = slugify(team.league.name)
        
        # Estrutura completa: static/teams/brasil/brasileirao-serie-a/144.png
        dir_path = os.path.join(escudos_dir, country_slug, league_slug)
        os.makedirs(dir_path, exist_ok=True)
        
        file_path = os.path.join(dir_path, f"{team.api_id}.png")
        
        if os.path.exists(file_path):
            skipped += 1
            continue
            
        # Determinar qual API usar para baixar a imagem
        if team.api_id.startswith('sofa_'):
            sofa_id = team.api_id.replace('sofa_', '')
            url = f"https://api.sofascore.app/api/v1/team/{sofa_id}/image"
        else:
            url = f"https://media.api-sports.io/football/teams/{team.api_id}.png"
        
        try:
            time.sleep(0.3)
            response = session.get(url, timeout=15)
            
            if response.status_code == 200:
                with open(file_path, 'wb') as f:
                    f.write(response.content)
                print(f"[{downloaded+1}] Baixado: {team.name} ({country_slug}/{league_slug}/{team.api_id}.png)")
                downloaded += 1
            else:
                print(f"[ERRO] {team.name} (HTTP {response.status_code}) - URL: {url}")
                errors += 1
        except Exception as e:
            print(f"[ERRO] {team.name}: Falha na conexão - {e}")
            errors += 1

    print("\nResumo Final da Organização (STATIC/TEAMS):")
    print(f"Novos escudos baixados: {downloaded}")
    print(f"Escudos mantidos (já existiam): {skipped}")
    print(f"Erros encontrados: {errors}")

if __name__ == '__main__':
    download_escudos()
