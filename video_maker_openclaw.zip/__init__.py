# Video Maker app init
